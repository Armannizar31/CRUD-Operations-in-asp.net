﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace MyWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        bool InsertJobPosting(Job obj);
        [OperationContract]
        DataSet SelectJobPosting();
        [OperationContract]
        bool UpdateJobPosting(Job obj);
        [OperationContract]
        bool DeleteJobPosting(int jobid);
    }

    [DataContract]
    public class Job
    {
        int id;
        int user_id;
        string title;
        string company;
        string department;
        string location;
        string salary;
        string experience;
        string last_date;
        string description;
        string requirements;
        [DataMember]
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        [DataMember]
        public int User_id
        {
            get { return user_id; }
            set { user_id = value; }
        }
        [DataMember]
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        [DataMember]
        public string Company
        {
            get { return company; }
            set { company = value; }
        }
        [DataMember]
        public string Department
        {
            get { return department; }
            set { department = value; }
        }
        [DataMember]
        public string Location
        {
            get { return location; }
            set { location = value; }
        }
        [DataMember]
        public string Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        [DataMember]
        public string Experience
        {
            get { return experience; }
            set { experience = value; }
        }
        [DataMember]
        public string Last_date
        {
            get { return last_date; }
            set { last_date = value; }
        }
        [DataMember]
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        [DataMember]
        public string Requirements
        {
            get { return requirements; }
            set { requirements = value; }
        }
    }
}
