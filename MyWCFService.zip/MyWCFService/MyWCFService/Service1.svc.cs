﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Drawing;

namespace MyWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public DataSet SelectJobPosting()
        {
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select * from jobposting", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            cmd.ExecuteNonQuery();
            conn.Close();
            return ds;
        }
        public bool InsertJobPosting(Job obj)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            string sql = "INSERT INTO jobposting (user_id,title,company,department,location,salary,experience,last_date,description,requirements) values (@user_id,@title,@company,@department,@location,@salary,@experience,@last_date,@description,@requirements)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@user_id",obj.User_id);
            cmd.Parameters.AddWithValue("@title", obj.Title);
            cmd.Parameters.AddWithValue("@company", obj.Company);
            cmd.Parameters.AddWithValue("@department", obj.Department);
            cmd.Parameters.AddWithValue("@location", obj.Location);
            cmd.Parameters.AddWithValue("@salary", obj.Salary);
            cmd.Parameters.AddWithValue("@experience", obj.Experience);
            cmd.Parameters.AddWithValue("@last_date", obj.Last_date);
            cmd.Parameters.AddWithValue("@description", obj.Description);
            cmd.Parameters.AddWithValue("@requirements", obj.Requirements);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            if (rows > 0)
            {
                isSuccess = true;
            }
            conn.Close();
            return isSuccess;
        }
        public bool UpdateJobPosting(Job obj)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            string sql = "UPDATE jobposting SET title=@title,company=@company,department=@department,location=@location,salary=@salary,experience=@experience,last_date=@last_date,description=@description,requirements=@requirements where id=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", obj.ID);
            cmd.Parameters.AddWithValue("@title", obj.Title);
            cmd.Parameters.AddWithValue("@company", obj.Company);
            cmd.Parameters.AddWithValue("@department", obj.Department);
            cmd.Parameters.AddWithValue("@location", obj.Location);
            cmd.Parameters.AddWithValue("@salary", obj.Salary);
            cmd.Parameters.AddWithValue("@experience", obj.Experience);
            cmd.Parameters.AddWithValue("@last_date", obj.Last_date);
            cmd.Parameters.AddWithValue("@description", obj.Description);
            cmd.Parameters.AddWithValue("@requirements", obj.Requirements);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            if (rows > 0)
            {
                isSuccess = true;
            }
            conn.Close();
            return isSuccess;
        }
        public bool DeleteJobPosting(int jobid)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            string sql = "DELETE FROM jobposting where id = @id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", jobid);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            if (rows > 0)
            {
                isSuccess = true;
            }
            conn.Close();
            return isSuccess;
        }
    }
}
