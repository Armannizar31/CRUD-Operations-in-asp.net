﻿truncate table appliedjob;
select * from jobposting;
select * from appliedjob;
delete from resume where id = 2;

insert into appliedjob(user_id, job_id) values(3,1);

select * from resume where user_id in (select user_id from appliedjob where job_id=1);