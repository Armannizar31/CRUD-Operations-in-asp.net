﻿--select user_type from users where email='sajjad@gmail.com' and password='123';
select * from users;
--truncate table users;