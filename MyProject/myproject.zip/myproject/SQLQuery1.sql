﻿CREATE TABLE jobposting (
id INT PRIMARY KEY IDENTITY (1, 1) NOT NULL,
user_id INT FOREIGN KEY REFERENCES users(Id) NOT NULL,
title NCHAR (100) NOT NULL,
company NCHAR (100) NOT NULL,
department NCHAR (100) NOT NULL,
location NCHAR (10) NOT NULL,
salary NCHAR (50) NOT NULL,
experience NCHAR (50) NOT NULL,
last_date NCHAR (50) NOT NULL,
description NCHAR (50) NOT NULL,
requirements NCHAR (50) NOT NULL
);

insert into resume
(user_id,fname,lname,email,title,gender,phone,address,degree,grade,objective,company,position,language1,language2,language3,interest1,interest2,interest3,skill1,skill2,skill3) 
values(2,'d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d');

select * from resume;
truncate table resume;