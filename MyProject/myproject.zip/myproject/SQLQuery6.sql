﻿CREATE TABLE appliedjob (
id INT PRIMARY KEY IDENTITY (1, 1) NOT NULL,
user_id INT FOREIGN KEY REFERENCES users(Id) NOT NULL,
job_id INT FOREIGN KEY REFERENCES jobposting(Id) NOT NULL
);

insert into resume
(user_id,fname,lname,email,title,gender,phone,address,degree,grade,objective,company,position,language1,language2,language3,interest1,interest2,interest3,skill1,skill2,skill3) 
values(2,'d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d');

truncate table appliedjob;

select * from appliedjob;
select * from jobposting;
Select j.id, j.title, j.company, j.salary, j.location from jobposting j where not exists (Select a.job_id from appliedjob a where a.job_id = j.id);