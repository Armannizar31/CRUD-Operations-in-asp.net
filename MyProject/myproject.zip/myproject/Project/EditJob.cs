﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class EditJob : Form
    {
        ServiceReference1.Service1Client obj1 = new ServiceReference1.Service1Client();
        public EditJob()
        {
            InitializeComponent();
            string Title=null, Company=null, Department=null, Location=null, Salary = null, Experience = null, Last_date = null, Description = null, Requirements = null;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            try
            {
                string sql = "SELECT title, company, department, location, salary, experience, last_date, description, requirements FROM jobposting where id = @id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", Program.jobid);
                conn.Open();
                SqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    Title = (string)dataReader.GetValue(0);
                    Company = (string)dataReader.GetValue(1);
                    Department = (string)dataReader.GetValue(2);
                    Location = (string)dataReader.GetValue(3);
                    Salary = (string)dataReader.GetValue(4);
                    Experience = (string)dataReader.GetValue(5);
                    Last_date = (string)dataReader.GetValue(6);
                    Description = (string)dataReader.GetValue(7);
                    Requirements = (string)dataReader.GetValue(8);
                }
                title.Text = Title.Replace(" ", String.Empty);
                company.Text = Company.Replace(" ", String.Empty);
                department.Text = Department.Replace(" ", String.Empty);
                Location = Location.Replace(" ", String.Empty);
                salary.Text = Salary.Replace(" ", String.Empty);
                experience.Text = Experience.Replace(" ", String.Empty);
                last_date.Text = Last_date.Replace(" ", String.Empty);
                description.Text = Description.Replace(" ", String.Empty);
                requirements.Text = Requirements.Replace(" ", String.Empty);
                if (Location=="remote")
                {
                    remote.Checked = true;
                }
                else
                {
                    onsite.Checked = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong." + e);
            }
            finally
            {
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.Job obj = new ServiceReference1.Job();
            obj.ID = Program.jobid;
            obj.User_id = Program.userid;
            obj.Title = title.Text;
            obj.Company = company.Text;
            obj.Department = department.Text;
            if (remote.Checked)
            {
                obj.Location = "remote";
            }
            else if (onsite.Checked)
            {
                obj.Location = "onsite";
            }
            else
            {
                MessageBox.Show("Please check the user type");
            }
            obj.Salary = salary.Text;
            obj.Experience = experience.Text;
            obj.Last_date = last_date.Text;
            obj.Description = description.Text;
            obj.Requirements = requirements.Text;
            if (obj1.UpdateJobPosting(obj))
            {
                MessageBox.Show("Saved Successfully!");
                this.Hide();
                Recruiter recruiter = new Recruiter();
                recruiter.ShowDialog();
            }
            else
            {
                MessageBox.Show("Failed to save!");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Recruiter obj = new Recruiter();
            obj.ShowDialog();
        }
    }
}
