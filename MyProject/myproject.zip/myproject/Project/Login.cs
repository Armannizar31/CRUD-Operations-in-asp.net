﻿using Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        LoginClass obj = new LoginClass();

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void signin_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Yippppppppppppppppppppy");
            obj.email = email.Text;
            obj.password = password.Text;
            string type = obj.validate(obj);
            if (type == "recruiter")
            {
                this.Hide();
                Recruiter recruiter = new Recruiter();
                recruiter.ShowDialog();
            }
            else if (type == "applicant")
            {
                int n=0;
                SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
                string sql = "SELECT count(*) FROM resume where user_id = @id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", Program.userid);
                conn.Open();
                SqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    n = (int)dataReader.GetValue(0);
                }
                if (n > 0)
                {
                    this.Hide();
                    EditResume edit = new EditResume();
                    edit.ShowDialog();
                }
                else
                {
                    this.Hide();
                    Applicant applicant = new Applicant();
                    applicant.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Email or password is wrong. Try Again!");
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Signup obj = new Signup();
            obj.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
