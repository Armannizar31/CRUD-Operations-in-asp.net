﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class JobApplicant : Form
    {
        ServiceReference1.Service1Client obj1 = new ServiceReference1.Service1Client();
        public JobApplicant()
        {
            InitializeComponent();
            showdata();
        }
        private void showdata()
        {
            string Title=null, Department = null, Salary = null, Location = null;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            string sql = "SELECT title, department, salary, location FROM jobposting where id = @id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", Program.jobid);
            conn.Open();
            SqlDataReader dataReader = cmd.ExecuteReader();
            while (dataReader.Read())
            {
                Title = (string)dataReader.GetValue(0);
                Department = (string)dataReader.GetValue(1);
                Salary = (string)dataReader.GetValue(2);
                Location = (string)dataReader.GetValue(3);
            }
            job_title.Text = Title.Replace(" ", String.Empty);
            department.Text = Department.Replace(" ", String.Empty);
            salary.Text = Salary.Replace(" ", String.Empty);
            location.Text = Location.Replace(" ", String.Empty);
            SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            connection.Open();
            SqlCommand command = new SqlCommand("select name=CONCAT(fname,' ',lname),email,phone,gender,title,address from resume where user_id in (select user_id from appliedjob where job_id=@job_id);", connection);
            command.Parameters.AddWithValue("@job_id", Program.jobid);
            SqlDataAdapter sda = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            command.ExecuteNonQuery();
            connection.Close();
            data.DataSource = ds.Tables[0];
            data.Columns[0].DataPropertyName = "name";
            data.Columns[1].DataPropertyName = "email";
            data.Columns[2].DataPropertyName = "phone";
            data.Columns[3].DataPropertyName = "gender";
            data.Columns[4].DataPropertyName = "title";
            data.Columns[5].DataPropertyName = "address";
            data.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void JobApplicant_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Recruiter obj = new Recruiter();
            obj.ShowDialog();
        }
    }
}
