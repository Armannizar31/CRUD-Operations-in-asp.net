﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class UpdateResume : Form
    {
        Service.WebService obj1 = new Service.WebService();
        public UpdateResume()
        {
            InitializeComponent();
            string Fname = null, Lname = null, Title = null, Gender = null, Email = null, Phone = null, Address = null, Degree = null, Grade = null, Objective = null, Position = null, Company = null, Lang1 = null, Lang2 = null, Lang3 = null, int1 = null, int2 = null, int3 = null, skil1 = null, skil2 = null, skil3 = null;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            try
            {
                string sql = "SELECT fname, lname, title, gender, email, phone, address, degree, grade, objective, position, company, language1, language2, language3, interest1, interest2, interest3, skill1, skill2, skill3 FROM resume where user_id = @id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", Program.userid);
                conn.Open();
                SqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    Fname = (string)dataReader.GetValue(0);
                    Lname = (string)dataReader.GetValue(1);
                    Title = (string)dataReader.GetValue(2);
                    Gender = (string)dataReader.GetValue(3);
                    Email = (string)dataReader.GetValue(4);
                    Phone = (string)dataReader.GetValue(5);
                    Address = (string)dataReader.GetValue(6);
                    Degree = (string)dataReader.GetValue(7);
                    Grade = (string)dataReader.GetValue(8);
                    Objective = (string)dataReader.GetValue(9);
                    Position = (string)dataReader.GetValue(10);
                    Company = (string)dataReader.GetValue(11);
                    Lang1 = (string)dataReader.GetValue(12);
                    Lang2 = (string)dataReader.GetValue(13);
                    Lang3 = (string)dataReader.GetValue(14);
                    int1 = (string)dataReader.GetValue(15);
                    int2 = (string)dataReader.GetValue(16);
                    int3 = (string)dataReader.GetValue(17);
                    skil1 = (string)dataReader.GetValue(18);
                    skil2 = (string)dataReader.GetValue(19);
                    skil3 = (string)dataReader.GetValue(20);
                }
                fname.Text = Fname.Replace(" ", String.Empty);
                lname.Text = Lname.Replace(" ", String.Empty);
                title.Text = Title.Replace(" ", String.Empty);
                Gender = Gender.Replace(" ", String.Empty);
                email.Text = Email.Replace(" ", String.Empty);
                phone.Text = Phone.Replace(" ", String.Empty);
                address.Text = Address.Replace(" ", String.Empty);
                degree.Text = Degree.Replace(" ", String.Empty);
                grade.Text = Grade.Replace(" ", String.Empty);
                objective.Text = Objective.Replace(" ", String.Empty);
                position.Text = Position.Replace(" ", String.Empty);
                company.Text = Company.Replace(" ", String.Empty);
                language1.Text = Lang1.Replace(" ", String.Empty);
                language2.Text = Lang2.Replace(" ", String.Empty);
                language3.Text = Lang3.Replace(" ", String.Empty);
                interest1.Text = int1.Replace(" ", String.Empty);
                interest2.Text = int2.Replace(" ", String.Empty);
                interest3.Text = int3.Replace(" ", String.Empty);
                skill1.Text = skil1.Replace(" ", String.Empty);
                skill2.Text = skil2.Replace(" ", String.Empty);
                skill3.Text = skil3.Replace(" ", String.Empty);
                if (Gender == "male")
                {
                    male.Checked = true;
                }
                else
                {
                    female.Checked = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong." + e);
            }
            finally
            {
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Fname = null, Lname = null, Title = null, Gender = null, Email = null, Phone = null, Address = null, Degree = null, Grade = null, Objective = null, Position = null, Company = null, Lang1 = null, Lang2 = null, Lang3 = null, int1 = null, int2 = null, int3 = null, skil1 = null, skil2 = null, skil3 = null;
            if (male.Checked)
            {
                Gender = "male";
            }
            else if (female.Checked)
            {
                Gender = "female";
            }
            else
            {
                MessageBox.Show("Please check the user type");
            }
            Fname = fname.Text;
            Lname = lname.Text;
            Title = title.Text;
            Email = email.Text;
            Phone = phone.Text;
            Address = address.Text;
            Degree = degree.Text;
            Grade = grade.Text;
            Objective = objective.Text;
            Position = position.Text;
            Company = company.Text;
            Lang1 = language1.Text;
            Lang2 = language2.Text;
            Lang3 = language3.Text;
            int1 = interest1.Text;
            int2 = interest2.Text;
            int3 = interest3.Text;
            skil1 = skill1.Text;
            skil2 = skill2.Text;
            skil3 = skill3.Text;
            if (obj1.UpdateResume(Program.userid, Fname, Lname, Title, Gender, Email, Phone, Address, Degree, Grade, Objective, Position, Company, Lang1, Lang2, Lang3, int1, int2, int3, skil1, skil2, skil3))
            {
                MessageBox.Show("Saved Successfully!");
                this.Hide();
                EditResume edit = new EditResume();
                edit.ShowDialog();
            }
            else
            {
                MessageBox.Show("Failed to save!");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            EditResume obj = new EditResume();
            obj.ShowDialog();
        }
    }
}
