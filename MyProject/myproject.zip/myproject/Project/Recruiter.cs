﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Recruiter : Form
    {
        ServiceReference1.Service1Client obj1 = new ServiceReference1.Service1Client();
        public Recruiter()
        {
            InitializeComponent();
            showdata();
        }
        private void showdata()
        {
            DataSet ds = new DataSet();
            ds = obj1.SelectJobPosting();
            data.DataSource = ds.Tables[0];
            data.Columns[0].DataPropertyName = "id";
            data.Columns[1].DataPropertyName = "title";
            data.Columns[2].DataPropertyName = "department";
            data.Columns[3].DataPropertyName = "location";
            data.Columns[4].DataPropertyName = "salary";
            data.Columns[5].DataPropertyName = "last_date";
            data.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }
        private void job_Click(object sender, EventArgs e)
        {
            this.Hide();
            JobPosting obj = new JobPosting();
            obj.ShowDialog();
        }

        private void edit_Click(object sender, EventArgs e)
        {
            if(Program.jobid!=0)
            {
                this.Hide();
                EditJob obj = new EditJob();
                obj.ShowDialog();
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (Program.jobid != 0)
            {
                if(obj1.DeleteJobPosting(Program.jobid))
                {
                    MessageBox.Show("Successfully Deleted!");
                }
                else
                {
                    MessageBox.Show("Failed to delete!");
                }
                this.Hide();
                Recruiter obj = new Recruiter();
                obj.ShowDialog();
            }
        }

        private void data_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedrow = data.Rows[index];
            Program.jobid = (int)selectedrow.Cells[0].Value;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Program.jobid != 0)
            {
                this.Hide();
                JobApplicant obj = new JobApplicant();
                obj.ShowDialog();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login obj = new Login();
            obj.ShowDialog();
        }
    }
}
