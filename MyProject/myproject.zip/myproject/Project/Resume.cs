﻿using Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Resume : Form
    {
        public Resume()
        {
            InitializeComponent();
        }
        ResumeClass obj = new ResumeClass();

        private void Resume_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj.fname = fname.Text;
            obj.lname = lname.Text;
            obj.title = title.Text;
            if(male.Checked)
            {
                obj.gender = "male";
            }
            else if (female.Checked)
            {
                obj.gender = "female";
            }
            else
            {
                MessageBox.Show("Please check the gender");
            }
            obj.address = address.Text;
            obj.email = email.Text;
            obj.phone = phone.Text;
            obj.grade = grade.Text;
            obj.degree = degree.Text;
            obj.objective = objective.Text;
            obj.position = position.Text;
            obj.company = company.Text;
            obj.language1= language1.Text;
            obj.language2 = language2.Text;
            obj.language3 = language3.Text;
            obj.skill1 = skill1.Text;
            obj.skill2 = skill2.Text;
            obj.skill3 = skill3.Text;
            obj.interest1 = interest1.Text;
            obj.interest2 = interest2.Text;
            obj.interest3 = interest3.Text;
            bool success = obj.AddResume(obj);
            if (success)
            {
                MessageBox.Show("Saved Successfully!");
                this.Hide();
                EditResume editr = new EditResume();
                editr.ShowDialog();
            }
            else
            {
                MessageBox.Show("Failed to save!");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Applicant obj = new Applicant();
            obj.ShowDialog();
        }
    }
}
