﻿using Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }
        LoginClass obj = new LoginClass();

        private void submit_Click(object sender, EventArgs e)
        {
            if(recruiter.Checked)
            {
                obj.user_type = "recruiter";
            }
            else if(applicant.Checked)
            {
                obj.user_type = "applicant";
            }
            else
            {
                MessageBox.Show("Please check the user type");
            }
            obj.email = email.Text;
            obj.password = password.Text;
            bool success = obj.AddUser(obj);
            if(success)
            {
                MessageBox.Show("Successfully added!");
                if (recruiter.Checked)
                {
                    this.Hide();
                    Applicant applicant = new Applicant();
                    applicant.ShowDialog();
                }
                else if (applicant.Checked)
                {
                    this.Hide();
                    Applicant applicant = new Applicant();
                    applicant.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Failed to sign up. Try Again!");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login obj = new Login();
            obj.ShowDialog();
        }
    }
}
