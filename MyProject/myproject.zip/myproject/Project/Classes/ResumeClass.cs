﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Classes
{
    internal class ResumeClass
    {
        public int id { get; set; }
        public string user_id { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public string email { get; set; }
        public string title { get; set; }
        public string gender { get; set; }
        public string phone { get; set; }
        public string address { get; set; }
        public string degree { get; set; }
        public string grade { get; set; }
        public string objective { get; set; }
        public string company { get; set; }
        public string position { get; set; }
        public string skill1 { get; set; }
        public string skill2 { get; set; }
        public string skill3 { get; set; }
        public string interest1 { get; set; }
        public string interest2 { get; set; }
        public string interest3 { get; set; }
        public string language1 { get; set; }
        public string language2 { get; set; }
        public string language3 { get; set; }
        public bool AddResume(ResumeClass obj)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");

            try
            {
                string sql = "INSERT INTO resume (user_id,fname,lname,email,title,gender,phone,address,degree,grade,objective,company,position,language1,language2,language3,interest1,interest2,interest3,skill1,skill2,skill3) values (@user_id,@fname,@lname,@email,@title,@gender,@phone,@address,@degree,@grade,@objective,@company,@position,@language1,@language2,@language3,@interest1,@interest2,@interest3,@skill1,@skill2,@skill3)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@user_id", Program.userid);
                cmd.Parameters.AddWithValue("@fname", obj.fname);
                cmd.Parameters.AddWithValue("@lname", obj.lname);
                cmd.Parameters.AddWithValue("@email", obj.email);
                cmd.Parameters.AddWithValue("@title", obj.title);
                cmd.Parameters.AddWithValue("@gender", obj.gender);
                cmd.Parameters.AddWithValue("@phone", obj.phone);
                cmd.Parameters.AddWithValue("@address", obj.address);
                cmd.Parameters.AddWithValue("@degree", obj.degree);
                cmd.Parameters.AddWithValue("@grade", obj.grade);
                cmd.Parameters.AddWithValue("@objective", obj.objective);
                cmd.Parameters.AddWithValue("@company", obj.company);
                cmd.Parameters.AddWithValue("@position", obj.position);
                cmd.Parameters.AddWithValue("@language1", obj.language1);
                cmd.Parameters.AddWithValue("@language2", obj.language2);
                cmd.Parameters.AddWithValue("@language3", obj.language3);
                cmd.Parameters.AddWithValue("@interest1", obj.interest1);
                cmd.Parameters.AddWithValue("@interest2", obj.interest2);
                cmd.Parameters.AddWithValue("@interest3", obj.interest3);
                cmd.Parameters.AddWithValue("@skill1", obj.skill1);
                cmd.Parameters.AddWithValue("@skill2", obj.skill2);
                cmd.Parameters.AddWithValue("@skill3", obj.skill3);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong." + e);
            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }
    }
}
