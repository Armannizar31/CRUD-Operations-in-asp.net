﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Classes
{
    internal class LoginClass
    {
        public int id { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string user_type { get; set; }
        static string myconnstring = ConfigurationManager.ConnectionStrings["connstr"].ConnectionString;

        public bool AddUser (LoginClass obj)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");

            try
            {
                string sql = "INSERT INTO users (email, password, user_type) VALUES (@email, @password, @user_type)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@email", obj.email);
                cmd.Parameters.AddWithValue("@password", obj.password);
                cmd.Parameters.AddWithValue("@user_type", obj.user_type);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if(rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("OOPs, something went wrong." + e);
            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }
        public string validate(LoginClass obj)
        {
            string type = null;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");

            try
            {
                string sql = "SELECT Id, user_type FROM users where email = @email and password = @password";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@email", obj.email);
                cmd.Parameters.AddWithValue("@password", obj.password);
                conn.Open();
                SqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    Program.userid = (int)dataReader.GetValue(0);
                    type = (string)dataReader.GetValue(1);
                }
                type = type.Replace(" ", String.Empty);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    Console.WriteLine(Program.userid);
                    Console.WriteLine(type);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong." + e);
            }
            finally
            {
                conn.Close();
            }
            return type;
        }
    }
}
