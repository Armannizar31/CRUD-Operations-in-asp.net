﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class JobDetails : Form
    {
        public JobDetails()
        {
            InitializeComponent();
            string Title = null, Company = null, Department = null, Location = null, Salary = null, Experience = null, Last_date = null, Description = null, Requirements = null;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            try
            {
                string sql = "SELECT title, company, department, location, salary, experience, last_date, description, requirements FROM jobposting where id = @id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", Program.applyjobid);
                conn.Open();
                SqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    Title = (string)dataReader.GetValue(0);
                    Company = (string)dataReader.GetValue(1);
                    Department = (string)dataReader.GetValue(2);
                    Location = (string)dataReader.GetValue(3);
                    Salary = (string)dataReader.GetValue(4);
                    Experience = (string)dataReader.GetValue(5);
                    Last_date = (string)dataReader.GetValue(6);
                    Description = (string)dataReader.GetValue(7);
                    Requirements = (string)dataReader.GetValue(8);
                }
                title.Text = Title.Replace(" ", String.Empty);
                company.Text = Company.Replace(" ", String.Empty);
                department.Text = Department.Replace(" ", String.Empty);
                location.Text = Location.Replace(" ", String.Empty);
                salary.Text = Salary.Replace(" ", String.Empty);
                experience.Text = Experience.Replace(" ", String.Empty);
                last_date.Text = Last_date.Replace(" ", String.Empty);
                description.Text = Description.Replace(" ", String.Empty);
                requirements.Text = Requirements.Replace(" ", String.Empty);
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong." + e);
            }
            finally
            {
                conn.Close();
            }
        }

        private void JobDetails_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            EditResume obj = new EditResume();
            obj.ShowDialog();
        }
    }
}
