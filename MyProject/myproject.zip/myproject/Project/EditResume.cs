﻿using System.Text.Json;
using Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Project
{
    public partial class EditResume : Form
    {
        Service.WebService obj1 = new Service.WebService();
        public EditResume()
        {
            InitializeComponent();
            string result = obj1.SelectJobPosting(Program.userid);
            DataSet myobj = JsonConvert.DeserializeObject<DataSet>(result);
            showdata(myobj);
        }
        private void showdata(DataSet myobj)
        {
            
            data.DataSource = myobj.Tables[0];
            data.Columns[0].DataPropertyName = "id";
            data.Columns[1].DataPropertyName = "title";
            data.Columns[2].DataPropertyName = "company";
            data.Columns[3].DataPropertyName = "salary";
            data.Columns[4].DataPropertyName = "location";
            data.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (Program.applyjobid != 0)
            {
                if (obj1.InsertJobApply(Program.applyjobid, Program.userid) == true)
                {
                    MessageBox.Show("Successfully Applied!");
                }
                else
                {
                    MessageBox.Show("Failed to apply!");
                }
                this.Hide();
                Applicant obj = new Applicant();
                obj.ShowDialog();
            }
        }

        private void edit_Click(object sender, EventArgs e)
        {
            if(Program.applyjobid != 0)
            {
                this.Hide();
                JobDetails obj = new JobDetails();
                obj.ShowDialog();
            }
        }

        private void resume_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateResume resume = new UpdateResume();
            resume.ShowDialog();
        }

        private void data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedrow = data.Rows[index];
            Program.applyjobid = (int)selectedrow.Cells[0].Value;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login obj = new Login();
            obj.ShowDialog();
        }
    }
}
