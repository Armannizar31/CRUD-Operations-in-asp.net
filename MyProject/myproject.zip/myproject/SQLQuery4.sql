﻿CREATE TABLE resume (
id INT PRIMARY KEY IDENTITY (1, 1) NOT NULL,
user_id INT FOREIGN KEY REFERENCES users(Id) NOT NULL,
fname NCHAR (50) NOT NULL,
lname NCHAR (50) NOT NULL,
email NCHAR (50) NOT NULL,
title NCHAR (50) NOT NULL,
gender NCHAR (50) NOT NULL,
phone NCHAR (50) NOT NULL,
address NCHAR (50) NOT NULL,
degree NCHAR (50) NOT NULL,
grade NCHAR (50) NOT NULL,
objective NCHAR (50) NOT NULL,
company NCHAR (50) NOT NULL,
position NCHAR (50) NOT NULL,
language1 NCHAR (50) NOT NULL,
language2 NCHAR (50),
language3 NCHAR (50),
interest1 NCHAR (50) NOT NULL,
interest2 NCHAR (50),
interest3 NCHAR (50),
skill1 NCHAR (50) NOT NULL,
skill2 NCHAR (50),
skill3 NCHAR (50)
);

insert into resume
(user_id,fname,lname,email,title,gender,phone,address,degree,grade,objective,company,position,language1,language2,language3,interest1,interest2,interest3,skill1,skill2,skill3) 
values(2,'d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d','d');

select * from resume;
truncate table resume;