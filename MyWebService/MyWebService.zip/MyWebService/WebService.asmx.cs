﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Diagnostics;
using System.Net;
using System.Security.AccessControl;
using System.Security.Policy;
using System.Xml.Linq;
using Newtonsoft.Json;

namespace MyWebService
{
    /// <summary>
    /// Summary description for WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string SelectJobPosting(int user_id)
        {
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select j.id, j.title, j.company, j.salary, j.location from jobposting j where not exists (Select a.job_id from appliedjob a where a.job_id = j.id and a.user_id = @user_id);", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            cmd.Parameters.AddWithValue("@user_id", user_id);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            cmd.ExecuteNonQuery();
            conn.Close();
            return JsonConvert.SerializeObject(ds, Newtonsoft.Json.Formatting.Indented);
        }
        [WebMethod]
        public bool InsertJobApply(int job_id, int user_id)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            string sql = "INSERT INTO appliedjob (user_id, job_id) values (@user_id, @job_id)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@user_id", user_id);
            cmd.Parameters.AddWithValue("@job_id", job_id);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            if (rows > 0)
            {
                isSuccess = true;
            }
            conn.Close();
            return isSuccess;
        }
        [WebMethod]
        public bool UpdateResume(int id, string Fname, string Lname, string Title, string Gender, string Email, string Phone, string Address, string Degree, string Grade, string Objective, string Position, string Company, string Lang1, string Lang2, string Lang3, string int1, string int2, string int3, string skil1, string skil2, string skil3)
        {
            bool isSuccess = true;
            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
            string sql = "UPDATE resume SET fname=@fname, lname=@lname, title=@title, gender=@gender, email=@email, phone=@phone, address=@address, degree=@degree, grade=@grade, objective=@objective, position=@position, company=@company, language1=@language1, language2=@language2, language3=@language3, interest1=@interest1, interest2=@interest2, interest3=@interest3, skill1=@skill1, skill2=@skill2, skill3=@skill3 where user_id=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@user_id", id);
            cmd.Parameters.AddWithValue("@fname", Fname);
            cmd.Parameters.AddWithValue("@lname", Lname);
            cmd.Parameters.AddWithValue("@title", Title);
            cmd.Parameters.AddWithValue("@gender", Gender);
            cmd.Parameters.AddWithValue("@email", Email);
            cmd.Parameters.AddWithValue("@phone", Phone);
            cmd.Parameters.AddWithValue("@address", Address);
            cmd.Parameters.AddWithValue("@degree", Degree);
            cmd.Parameters.AddWithValue("@grade", Grade);
            cmd.Parameters.AddWithValue("@objective", Objective);
            cmd.Parameters.AddWithValue("@position", Position);
            cmd.Parameters.AddWithValue("@company", Company);
            cmd.Parameters.AddWithValue("@language1", Lang1);
            cmd.Parameters.AddWithValue("@language2", Lang2);
            cmd.Parameters.AddWithValue("@language3", Lang3);
            cmd.Parameters.AddWithValue("@interest1", int1);
            cmd.Parameters.AddWithValue("@interest2", int2);
            cmd.Parameters.AddWithValue("@interest3", int3);
            cmd.Parameters.AddWithValue("@skill1", skil1);
            cmd.Parameters.AddWithValue("@skill2", skil2);
            cmd.Parameters.AddWithValue("@skill3", skil3);
            conn.Open();
            conn.Close();
            return isSuccess;
        }
    }
}
