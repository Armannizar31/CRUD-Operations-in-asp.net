﻿CREATE TABLE webresume (
id INT PRIMARY KEY IDENTITY (1, 1) NOT NULL,
user_id INT FOREIGN KEY REFERENCES users(Id) NOT NULL,
name NCHAR (50) NOT NULL,
title NCHAR (50) NOT NULL,
linkedin NCHAR (50) NOT NULL,
github NCHAR (50) NOT NULL,
email NCHAR (50) NOT NULL,
phone NCHAR (50) NOT NULL,
comp_name NCHAR (50) NOT NULL,
position NCHAR (50) NOT NULL,
certification_link NCHAR (50) NOT NULL,
location NCHAR (50) NOT NULL,
job_start NCHAR (50) NOT NULL,
job_end NCHAR (50) NOT NULL,
job_desc NCHAR (50) NOT NULL,
project_title NCHAR (50) NOT NULL,
overview NCHAR (50) NOT NULL,
dep_link NCHAR (50) NOT NULL,
dep_git_link NCHAR (50) NOT NULL,
project_desc NCHAR (50) NOT NULL,
edu_title NCHAR (50) NOT NULL,
institute NCHAR (50) NOT NULL,
edu_start NCHAR (50) NOT NULL,
edu_end NCHAR (50) NOT NULL,
achieve_title NCHAR (50) NOT NULL,
objective NCHAR (50) NOT NULL,
interests NCHAR (50) NOT NULL
);
user_id,name,title,linkedin,github,email,phone,comp_name,position,certification_link,location,job_start,job_end,job_desc,project_title,overview,dep_link,dep_git_link,project_desc,edu_title,institute,edu_start,edu_end,achieve_title,objective,interests


truncate table webresume;
select * from webresume;
INSERT INTO webresume (user_id,name,title,linkedin,github,email,phone,comp_name,position,certification_link,location,job_start,job_end,job_desc,project_title,overview,dep_link,dep_git_link,project_desc,edu_title,institute,edu_start,edu_end,achieve_title,objective,interests) values (1,'name','title','linkedin','github','email','phone','comp_name','position','certification_link','location','job_start','job_end','job_desc','project_title','overview','dep_link','dep_git_link','project_desc','edu_title','institute','edu_start','edu_end','achieve_title','objective','interests')