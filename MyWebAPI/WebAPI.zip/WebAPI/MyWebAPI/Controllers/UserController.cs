﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MyWebAPI.Models;

namespace MyWebAPI.Controllers
{
    [RoutePrefix("Api/User")]
    public class UserController : ApiController
    {
        SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
        SqlCommand cmd = null;
        SqlDataAdapter da = null;

        [HttpPost]
        [Route("SignUp")]
        public Tuple<int, string, string> SingUp(User obj)
        {
            string msg;
            string type = null;
            int id = 0;
                string sql = "INSERT INTO users (email, password, user_type) values (@email, @password, @user_type)" + "SELECT CAST(scope_identity() AS int)";
                cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@email", obj.email);
                cmd.Parameters.AddWithValue("@password", obj.password);
                cmd.Parameters.AddWithValue("@user_type", obj.user_type);
                conn.Open();
                id = (Int32)cmd.ExecuteScalar();
                int n = cmd.ExecuteNonQuery();
                if (n > 0)
                {
                    msg = "Singned Up Successfully!";
                    type = obj.user_type;
                    //type = type.Replace(" ", String.Empty);
                }
                else
                {
                    msg = "Oops Something Went Wrong!";
                }
            conn.Close();
            Tuple<int, string, string> userD = new Tuple<int, string, string>(id, type, msg);
            return userD;
        }

        [HttpPost]
        [Route("SignIn")]
        public Tuple<int, string, string> SingIn(User obj)
        {
            string msg = null;
            string type = null;
            int id = 0;
            try
            {
                string sql = "SELECT Id, user_type FROM users where email = @email and password = @password";
                da = new SqlDataAdapter(sql, conn);
                da.SelectCommand.Parameters.AddWithValue("@email", obj.email);
                da.SelectCommand.Parameters.AddWithValue("@password", obj.password);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    msg = "Logged in Successfully!";
                    type = dt.Rows[0].Field<String>("user_type");
                    type = type.Replace(" ", String.Empty);
                    id = dt.Rows[0].Field<int>("Id");
                }
                else
                {
                    msg = "Email or Password is Incorrect!";
                }
            }
            catch (Exception e)
            {
                msg = e.Message;
            }
            finally
            {
                conn.Close();
            }
            Tuple<int, string, string> userD = new Tuple<int, string, string>(id, type, msg);
            return userD;
        }

        [HttpPost]
        [Route("AddResume")]
        public string AddResume(Resumee obj)
        {
            string msg;
                string sql = "INSERT INTO resume (user_id,fname,lname,email,title,gender,phone,address,degree,grade,objective,company,position,language1,language2,language3,interest1,interest2,interest3,skill1,skill2,skill3) values (@user_id,@fname,@lname,@email,@title,@gender,@phone,@address,@degree,@grade,@objective,@company,@position,@language1,@language2,@language3,@interest1,@interest2,@interest3,@skill1,@skill2,@skill3)";
                cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@user_id", obj.user_id);
                cmd.Parameters.AddWithValue("@fname", obj.fname);
                cmd.Parameters.AddWithValue("@lname", obj.lname);
                cmd.Parameters.AddWithValue("@email", obj.email);
                cmd.Parameters.AddWithValue("@title", obj.title);
                cmd.Parameters.AddWithValue("@gender", obj.gender);
                cmd.Parameters.AddWithValue("@phone", obj.phone);
                cmd.Parameters.AddWithValue("@address", obj.address);
                cmd.Parameters.AddWithValue("@degree", obj.degree);
                cmd.Parameters.AddWithValue("@grade", obj.grade);
                cmd.Parameters.AddWithValue("@objective", obj.objective);
                cmd.Parameters.AddWithValue("@company", obj.company);
                cmd.Parameters.AddWithValue("@position", obj.position);
                cmd.Parameters.AddWithValue("@language1", obj.language1);
                cmd.Parameters.AddWithValue("@language2", obj.language2);
                cmd.Parameters.AddWithValue("@language3", obj.language3);
                cmd.Parameters.AddWithValue("@interest1", obj.interest1);
                cmd.Parameters.AddWithValue("@interest2", obj.interest2);
                cmd.Parameters.AddWithValue("@interest3", obj.interest3);
                cmd.Parameters.AddWithValue("@skill1", obj.skill1);
                cmd.Parameters.AddWithValue("@skill2", obj.skill2);
                cmd.Parameters.AddWithValue("@skill3", obj.skill3);
                conn.Open();
                int n = cmd.ExecuteNonQuery();
            conn.Close();
                if (n > 0)
                {
                    msg = "Saved Successfully!";
                }
                else
                {
                    msg = "Failed to Save!";
                }
            return msg;
        }
    }
}
