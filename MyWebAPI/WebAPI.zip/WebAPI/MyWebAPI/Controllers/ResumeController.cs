﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MyWebAPI.Models;

namespace MyWebAPI.Controllers
{
    [RoutePrefix("Api/Resume")]
    public class ResumeController : ApiController
    {
        SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True");
        SqlCommand cmd = null;
        SqlDataAdapter da = null;

        [HttpPost]
        [Route("AddResume")]
        public string AddResume(Resume obj)
        {
            string msg;
                Console.WriteLine(obj);
                string sql = "INSERT INTO webresume (user_id,name,title,linkedin,github,email,phone,comp_name,position,certification_link,location,job_start,job_end,job_desc,project_title,overview,dep_link,dep_git_link,project_desc,edu_title,institute,edu_start,edu_end,achieve_title,objective,interests) values (@user_id,@name,@title,@linkedin,@github,@email,@phone,@comp_name,@position,@certification_link,@location,@job_start,@job_end,@job_desc,@project_title,@overview,@dep_link,@dep_git_link,@project_desc,@edu_title,@institute,@edu_start,@edu_end,@achieve_title,@objective,@interests)";
                cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@user_id", obj.user_id);
                cmd.Parameters.AddWithValue("@name", obj.name);
                cmd.Parameters.AddWithValue("@title", obj.title);
                cmd.Parameters.AddWithValue("@linkedin", obj.linkedin);
                cmd.Parameters.AddWithValue("@github", obj.github);
                cmd.Parameters.AddWithValue("@email", obj.email);
                cmd.Parameters.AddWithValue("@phone", obj.phone);
                cmd.Parameters.AddWithValue("@comp_name", obj.comp_name);
                cmd.Parameters.AddWithValue("@position", obj.position);
                cmd.Parameters.AddWithValue("@certification_link", obj.certification_link);
                cmd.Parameters.AddWithValue("@location", obj.location);
                cmd.Parameters.AddWithValue("@job_start", obj.job_start);
                cmd.Parameters.AddWithValue("@job_end", obj.job_end);
                cmd.Parameters.AddWithValue("@job_desc", obj.job_desc);
                cmd.Parameters.AddWithValue("@project_title", obj.project_title);
                cmd.Parameters.AddWithValue("@overview", obj.overview);
                cmd.Parameters.AddWithValue("@dep_link", obj.dep_link);
                cmd.Parameters.AddWithValue("@dep_git_link", obj.dep_git_link);
                cmd.Parameters.AddWithValue("@project_desc", obj.project_desc);
                cmd.Parameters.AddWithValue("@edu_title", obj.edu_title);
                cmd.Parameters.AddWithValue("@institute", obj.institute);
                cmd.Parameters.AddWithValue("@edu_start", obj.edu_start);
                cmd.Parameters.AddWithValue("@edu_end", obj.edu_end);
                cmd.Parameters.AddWithValue("@achieve_title", obj.achieve_title);
                cmd.Parameters.AddWithValue("@objective", obj.objective);
                cmd.Parameters.AddWithValue("@interests", obj.interests);
                conn.Open();
                int n = cmd.ExecuteNonQuery();
            conn.Close();
                if (n > 0)
                {
                    msg = "Saved Successfully!";
                }
                else
                {
                    msg = "Failed to Save!";
                }
            return msg;
        }

        [HttpGet]
        [Route("AllUsers")]
        public AllUserss[] AllUsers()
        {
            string sql = "SELECT u.Id, r.fname, r.lname, u.email FROM users u, resume r where u.Id = r.user_id";
            da = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int n = dt.Rows.Count;
            AllUserss[] obj = new AllUserss[n];
            for (int i = 0; i < n; i++)
            {
                obj[i] = new AllUserss();
                obj[i].Id = dt.Rows[i].Field<int>("Id");
                obj[i].fname = dt.Rows[i].Field<String>("fname");
                obj[i].lname = dt.Rows[i].Field<String>("lname");
                obj[i].email = dt.Rows[i].Field<String>("email");
            }
            return obj;
        }
    }
}
