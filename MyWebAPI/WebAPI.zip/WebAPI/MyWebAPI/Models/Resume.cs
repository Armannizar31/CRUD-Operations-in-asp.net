﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWebAPI.Models
{
    public class Resume
    {
        public int Id { get; set; }
        public int user_id { get; set; }
        public string name { get; set; }
        public string title { get; set; }
        public string linkedin { get; set; }
        public string github { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string comp_name { get; set; }
        public string position { get; set; }
        public string certification_link { get; set; }
        public string location { get; set; }
        public string job_start { get; set; }
        public string job_end { get; set; }
        public string job_desc { get; set; }
        public string project_title { get; set; }
        public string overview { get; set; }
        public string dep_link { get; set; }
        public string dep_git_link { get; set; }
        public string project_desc { get; set; }
        public string edu_title { get; set; }
        public string institute { get; set; }
        public string edu_start { get; set; }
        public string edu_end { get; set; }
        public string achieve_title { get; set; }
        public string objective { get; set; }
        public string interests { get; set; }
    }
}