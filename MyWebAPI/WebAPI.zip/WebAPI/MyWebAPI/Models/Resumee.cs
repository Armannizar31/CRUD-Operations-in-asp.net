﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWebAPI.Models
{
    public class Resumee
    {
        public int Id { get; set; }
        public int user_id { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public string email { get; set; }
        public string title { get; set; }
        public string gender { get; set; }
        public string phone { get; set; }
        public string address { get; set; }
        public string degree { get; set; }
        public string grade { get; set; }
        public string objective { get; set; }
        public string company { get; set; }
        public string position { get; set; }
        public string language1 { get; set; }
        public string language2 { get; set; }
        public string language3 { get; set; }
        public string interest1 { get; set; }
        public string interest2 { get; set; }
        public string interest3 { get; set; }
        public string skill1 { get; set; }
        public string skill2 { get; set; }
        public string skill3 { get; set; }
    }
}