﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWebAPI.Models
{
    public class AllUserss
    {
        public int Id { get; set; }
        public string email { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
    }
}